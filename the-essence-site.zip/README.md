# THE ESSENCE — Full Website + Store (Stripe + Printful)

Upload this folder to GitHub, then import the repo into Vercel.
Add env vars in Vercel: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, PRINTFUL_API_KEY, SITE_URL.
Edit js/store.js to paste your Stripe price IDs and Printful variant IDs.
