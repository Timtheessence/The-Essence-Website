import Stripe from 'stripe';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { items } = req.body || {};
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'No items' });
  }

  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

    const line_items = items.map(i => ({
      price: i.stripePriceId,
      quantity: i.quantity
    }));

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items,
      success_url: `${process.env.SITE_URL}/success.html`,
      cancel_url: `${process.env.SITE_URL}/cancel.html`,
      shipping_address_collection: { allowed_countries: ['US','CA','GB','AU','NZ','IE','DE','FR','ES','IT','SE','NO','FI','NL','BE','DK'] },
      phone_number_collection: { enabled: true },
      metadata: {
        printful: JSON.stringify(items.map(i => ({variant_id: i.printfulVariantId, quantity: i.quantity, name: i.name})))
      }
    });

    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
}
