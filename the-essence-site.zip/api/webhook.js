import Stripe from 'stripe';

export const config = { api: { bodyParser: false } };

function buffer(body) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    body.on('data', (chunk) => chunks.push(chunk));
    body.on('end', () => resolve(Buffer.concat(chunks)));
    body.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const sig = req.headers['stripe-signature'];
  const buf = await buffer(req);

  let event;
  try {
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const shipping = session.shipping_details;
    const email = session.customer_details?.email;

    let printfulItems = [];
    try { printfulItems = JSON.parse(session.metadata?.printful || '[]'); } catch (e) {}

    const payload = {
      recipient: {
        name: shipping?.name || 'Customer',
        address1: shipping?.address?.line1,
        address2: shipping?.address?.line2 || '',
        city: shipping?.address?.city,
        state_code: shipping?.address?.state,
        country_code: shipping?.address?.country,
        zip: shipping?.address?.postal_code,
        phone: session.customer_details?.phone || '',
        email
      },
      items: printfulItems.map(i => ({
        variant_id: Number(i.variant_id || i.printfulVariantId),
        quantity: Number(i.quantity),
        name: i.name
      })),
      packing_slip: {
        email,
        message: 'Thank you for supporting THE ESSENCE!'
      }
    };

    try {
      const resp = await fetch('https://api.printful.com/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.PRINTFUL_API_KEY}`
        },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();
      if (!resp.ok) console.error('Printful error:', data);
      else console.log('Printful order created:', data?.result?.id);
    } catch (err) {
      console.error('Printful request failed:', err);
    }
  }

  res.json({ received: true });
}
